var buttonClickCounts = {
    1: 0,
    2: 0,
    3: 0
};

function changeImages(buttonNumber) {
    // Increment the click count for the specific button
    buttonClickCounts[buttonNumber]++;

    var image1 = document.getElementById('image1');
    var image2 = document.getElementById('image2');

    switch (buttonNumber) {
        case 1:
            image1.src = "images/1.jpg";
            image2.src = "images/bg1.jpg";
            break;
        case 2:
            image1.src = "images/2.jpg";
            image2.src = "images/bg2.jpg";
            break;
        case 3:
            image1.src = "images/3.jpg";
            image2.src = "images/bg3.jpg";
            break;
    }

    // Update the button text with the click count
    updateButtonClickCount(buttonNumber);
}

function updateButtonClickCount(buttonNumber) {
    var button = document.getElementById('button' + buttonNumber);
    button.textContent = buttonClickCounts[buttonNumber];
}